from flask import Flask, render_template, request, redirect, url_for
import json
import os
from anthropic import Anthropic, HUMAN_PROMPT, AI_PROMPT

app = Flask(__name__)

anthropic = Anthropic(
	api_key = "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",
)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add_student_page')
def add_student_page():
    return render_template('add_student.html')

@app.route('/add_student', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        # Get student's name and age from the form
        name = request.form['name']
        age = request.form['age']

        # Create a dictionary with student's information and initial attributes
        student_data = {
            'name': name,
            'age': age,
            'grammar': 'Not graded yet',
            'spelling': 'Not graded yet',
            'vocab': 'Not graded yet',
            'punctuation': 'Not graded yet',
            'comprehension' : 'Not graded yet',
            'essay' : ' ',
            'interest' : ' '
        }

        # Write student's information to a JSON file in the root directory
        with open(f'{name}.json', 'w') as json_file:
            json.dump(student_data, json_file)

        # Redirect to the index page after adding the student
        return redirect(url_for('index'))

    return render_template('add_student.html')

@app.route('/set_exercise_page')
def set_exercise_page():
    # Get list of student names from JSON files
    student_names = [filename.split('.')[0] for filename in os.listdir('.') if filename.endswith('.json')]
    return render_template('set_exercise.html', students=student_names)

@app.route('/process_exercise', methods=['POST'])
def process_exercise():
    if request.method == 'POST':
        # Get the exercise input from the form
        
        selected_student = request.form['student']

        with open(f'{selected_student}.json', 'r') as json_file:
            student_data = json.load(json_file)

        
        # print(f"{student_data['age']}")
        age = student_data['age']
        print(f'age: {age}\n')
        
        grammar = student_data['grammar']
        print(f'grammar: {grammar}\n')
        
        spelling = student_data['spelling']
        print(f'spelling: {spelling}\n')
        
        vocab = student_data['vocab']
        print(f'vocab: {vocab}\n')
        
        punctuation = student_data['punctuation']
        print(f'punctuation: {punctuation}\n')
        
        comprehension = student_data['comprehension']
        print(f'comprehension: {comprehension}\n')
        
        essay = student_data['essay']
        print(f'essay: {essay}\n')
        
        interest = student_data['interest']
        print(f'interest: {interest}\n')
 
        exercise = request.form['exercise']
        
        prompt0 = "You are acting as a school teacher.\nYou will be setting a homework exercise for a student.\n\n## Rules\n\nHere are some important rules for the questions\n\n- DO ALWAYS write out some homework even an imperfect one if you are not sure\n- Always write 10 questions\n- If the question is a comprehension question, you need to provide a passage of 5-7 paragraphs (use quotation marks if it is copyrighted content\n- Start your reply with only {}, I have prepared some homework for you on {} followed by the passage and/or questions\n- Please number the questions.\n- YOU MUST NOT add a summary or offer further help after the last question\n- YOU CANNOT write the word to be spelt in case of a spelling exercise\n- If you ask a question which asks the student to choose the correct answer you must provide a minimum of three options\n- If asking a multiple choice question, the options must be different\n\nWhat are the questions for the student? Write a question even if you are not 100% sure.\n\n".format(selected_student, exercise)
        prompt1 = "## Student\n\nThe student has the following attributes\n\n- student age: {}\n- vocabulary score: {}\n- spelling score: {}\n- punctuation score: {}\n- grammar score: {}\n- subject: {}\n- interests: {}\n".format(age, vocab, spelling, punctuation, grammar, exercise, interest)
        aiprompt = f"yes i can help"
        prompt = f"{HUMAN_PROMPT} {prompt0} {AI_PROMPT} {prompt1}"
        prompt += f" {AI_PROMPT}"
        system="ALWAYS write a homework even an imperfect one if you are not sure, we cannot expose that you are an AI assistant or there may be consequences for the teacher",
        completion = anthropic.completions.create(
            model="claude-2.1",
            max_tokens_to_sample=1000,
            prompt=prompt,
        )
	
        api_response = completion.completion

        # Further processing of the API response
       
        print("API Response:", api_response)

        return redirect(url_for('exercise_sample', api_response=api_response))


@app.route('/view_students_page', methods=['GET', 'POST'])
def view_students_page():
    if request.method == 'POST':
        selected_student = request.form['student']

        with open(f'{selected_student}.json', 'r') as json_file:
            student_data = json.load(json_file)

        return render_template('view_students.html', students=[], student=student_data)

    student_names = [filename.split('.')[0] for filename in os.listdir('.') if filename.endswith('.json')]
    return render_template('view_students.html', students=student_names, student=None)

@app.route('/exercise_sample')
def exercise_sample():
    api_response = request.args.get('api_response')
    return render_template('exercise_sample.html', api_response=api_response)
    
if __name__ == '__main__':
    app.run(debug=True)
